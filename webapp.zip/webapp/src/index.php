<?php
$host = getenv('DB_HOST');
$db   = getenv('DB_NAME');
$user = getenv('DB_USER');
$pass = getenv('DB_PASSWORD');

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<h1>Apache + PHP + MySQL Webpage</h1>";
echo "<p>Connected to database: <b>$db</b></p>";

$result = $conn->query("SELECT * FROM messages");

if ($result && $result->num_rows > 0) {
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>" . htmlspecialchars($row['content']) . " (" . $row['created_at'] . ")</li>";
    }
    echo "</ul>";
} else {
    echo "<p>No records found.</p>";
}

$conn->close();
?>
