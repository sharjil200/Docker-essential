<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/data/products.php';

require_login();

$cart  = $_SESSION['cart'] ?? [];
$items = [];
$total = 0.0;

foreach ($cart as $productId => $qty) {
    $product = get_product_by_id((int)$productId);
    if ($product) {
        $lineTotal = $product['price'] * $qty;
        $total    += $lineTotal;
        $items[]   = [
            'product'    => $product,
            'qty'        => $qty,
            'line_total' => $lineTotal,
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart - ShopDemo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="navbar">
        <div class="navbar-brand">ShopDemo</div>
        <nav class="navbar-links">
            <a href="products.php">← Continue Shopping</a>
            <a href="logout.php" class="logout-link">Log Out</a>
        </nav>
    </header>

    <main class="container">
        <h1>Your Cart</h1>

        <?php if (empty($items)): ?>
            <p class="empty-cart">Your cart is empty. <a href="products.php">Browse products</a>.</p>
        <?php else: ?>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td>
                                <span class="cart-emoji"><?= $item['product']['emoji'] ?></span>
                                <?= htmlspecialchars($item['product']['name']) ?>
                            </td>
                            <td>₹<?= number_format($item['product']['price'], 2) ?></td>
                            <td><?= (int)$item['qty'] ?></td>
                            <td>₹<?= number_format($item['line_total'], 2) ?></td>
                            <td>
                                <form method="POST" action="remove_from_cart.php">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                                    <input type="hidden" name="product_id" value="<?= (int)$item['product']['id'] ?>">
                                    <button type="submit" class="btn-remove">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="cart-total">
                Total: ₹<?= number_format($total, 2) ?>
            </div>

            <button class="btn-checkout" disabled title="Checkout not implemented in this prototype">
                Proceed to Checkout
            </button>
        <?php endif; ?>
    </main>
</body>
</html>
