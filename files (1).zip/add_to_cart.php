<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/data/products.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token     = $_POST['csrf_token'] ?? '';
    $productId = (int)($_POST['product_id'] ?? 0);

    if (csrf_valid($token) && get_product_by_id($productId) !== null) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        // Increment quantity if already in cart, else add with qty 1.
        $_SESSION['cart'][$productId] = ($_SESSION['cart'][$productId] ?? 0) + 1;
    }
}

header('Location: products.php');
exit;
