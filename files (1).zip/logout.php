<?php
require_once __DIR__ . '/includes/auth.php';

// Clear all session data and destroy the session.
$_SESSION = [];
session_destroy();

header('Location: login.php');
exit;
