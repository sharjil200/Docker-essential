<?php
/**
 * products.php
 * -------------------------------------------------------------------------
 * Returns the product catalog as an array.
 * In a production app this would be a database query (e.g. MySQL) instead
 * of a static array — swap get_products() to run a SELECT and the rest
 * of the app (products.php, cart.php) works unchanged.
 * -------------------------------------------------------------------------
 */

function get_products(): array
{
    return [
        [
            'id'          => 1,
            'name'        => 'Wireless Headphones',
            'price'       => 2499.00,
            'emoji'       => '🎧',
            'description' => 'Over-ear wireless headphones with noise cancellation and 30-hour battery life.',
        ],
        [
            'id'          => 2,
            'name'        => 'Mechanical Keyboard',
            'price'       => 3199.00,
            'emoji'       => '⌨️',
            'description' => 'Compact 75% mechanical keyboard with hot-swappable switches and RGB backlight.',
        ],
        [
            'id'          => 3,
            'name'        => 'Smart Watch',
            'price'       => 4999.00,
            'emoji'       => '⌚',
            'description' => 'Fitness tracking smartwatch with heart-rate monitor and 7-day battery.',
        ],
        [
            'id'          => 4,
            'name'        => 'Portable SSD 1TB',
            'price'       => 6999.00,
            'emoji'       => '💾',
            'description' => 'USB-C portable SSD with read speeds up to 1050MB/s.',
        ],
        [
            'id'          => 5,
            'name'        => 'Webcam 1080p',
            'price'       => 1899.00,
            'emoji'       => '📷',
            'description' => 'Full HD webcam with built-in mic, ideal for calls and streaming.',
        ],
        [
            'id'          => 6,
            'name'        => 'Bluetooth Speaker',
            'price'       => 1599.00,
            'emoji'       => '🔊',
            'description' => 'Compact waterproof speaker with 12-hour playback.',
        ],
    ];
}

/**
 * Fetches a single product by ID, or null if not found.
 */
function get_product_by_id(int $id): ?array
{
    foreach (get_products() as $product) {
        if ($product['id'] === $id) {
            return $product;
        }
    }
    return null;
}
