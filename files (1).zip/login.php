<?php
require_once __DIR__ . '/includes/auth.php';

// Already logged in? Skip straight to the catalog.
if (is_logged_in()) {
    header('Location: products.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token    = $_POST['csrf_token'] ?? '';
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!csrf_valid($token)) {
        $error = 'Invalid request. Please try again.';
    } elseif (validate_credentials($username, $password)) {
        // Prevent session fixation by issuing a fresh session ID on login.
        session_regenerate_id(true);
        $_SESSION['user'] = DEMO_USERNAME;
        header('Location: products.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ShopDemo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-card">
        <h1>ShopDemo</h1>
        <p class="subtitle">Sign in to continue</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php" novalidate>
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

            <label for="username">Username</label>
            <input type="text" id="username" name="username" autocomplete="username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" autocomplete="current-password" required>

            <button type="submit">Log In</button>
        </form>
    </div>
</body>
</html>
