<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/data/products.php';

require_login();

$products  = get_products();
$cart      = $_SESSION['cart'] ?? [];
$cartCount = array_sum($cart);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Catalog - ShopDemo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="navbar">
        <div class="navbar-brand">ShopDemo</div>
        <nav class="navbar-links">
            <a href="cart.php" class="cart-link">
                🛒 Cart <span class="cart-badge"><?= (int)$cartCount ?></span>
            </a>
            <a href="logout.php" class="logout-link">Log Out</a>
        </nav>
    </header>

    <main class="container">
        <h1>Product Catalog</h1>

        <div class="product-grid">
            <?php foreach ($products as $product): ?>
                <div class="product-card">
                    <div class="product-emoji"><?= $product['emoji'] ?></div>
                    <h2 class="product-name"><?= htmlspecialchars($product['name']) ?></h2>
                    <p class="product-description"><?= htmlspecialchars($product['description']) ?></p>
                    <p class="product-price">₹<?= number_format($product['price'], 2) ?></p>

                    <form method="POST" action="add_to_cart.php">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                        <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                        <button type="submit" class="btn-add-cart">Add to Cart</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>
