<?php
/**
 * auth.php
 * -------------------------------------------------------------------------
 * Central session bootstrap + authentication helpers.
 * Included at the top of every protected page.
 * -------------------------------------------------------------------------
 */

// Harden session cookie before starting the session.
session_set_cookie_params([
    'lifetime' => 0,        // Session cookie (expires when browser closes)
    'path'     => '/',
    'httponly' => true,     // Not accessible via JavaScript (mitigates XSS cookie theft)
    'samesite' => 'Lax',    // Basic CSRF mitigation for cross-site requests
    // 'secure' => true,     // Uncomment once served over HTTPS
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fixed demo credentials (as specified in requirements).
// In a real system these would live in a database with hashed passwords.
define('DEMO_USERNAME', 'sharjil@200');
define('DEMO_PASSWORD', 'sharjil200');

/**
 * Returns true if the current session belongs to a logged-in user.
 */
function is_logged_in(): bool
{
    return isset($_SESSION['user']) && $_SESSION['user'] === DEMO_USERNAME;
}

/**
 * Redirects to login.php if the user is not authenticated.
 * Call at the top of every page that requires a session.
 */
function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Validates submitted credentials against the fixed credential set.
 * Uses hash_equals() for a timing-attack-resistant string comparison.
 */
function validate_credentials(string $username, string $password): bool
{
    return hash_equals(DEMO_USERNAME, $username) && hash_equals(DEMO_PASSWORD, $password);
}

/**
 * Generates (or reuses) a CSRF token for the current session.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validates a submitted CSRF token against the session token.
 */
function csrf_valid(?string $token): bool
{
    return isset($_SESSION['csrf_token'], $token) && hash_equals($_SESSION['csrf_token'], $token);
}
